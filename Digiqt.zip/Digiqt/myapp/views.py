from django.shortcuts import render
from rest_framework.response import Response
from rest_framework import viewsets

from myapp.serializers import movieserializer
from .models import movie

class movieapi(viewsets.ViewSet):

    def create(self,request):
        pass
        
    def  list(self,request):
        movie_obj = movie.objects.all()
        serializer = movieserializer(movie_obj, many = True)
        return Response({'data':serializer.data})

    def retrieve(self,request,pk = None):
        movie_obj = movie.objects.filter(pk = pk).first()
        serializer = movieserializer(movie_obj)
        return Response({'data':serializer.data})

    def update(self,request,pk = None):
        pass

    def destroy(self,request, pk = None):
        movie.objects.filter(pk = pk).delete()
        return Response({'data': 'delete'})