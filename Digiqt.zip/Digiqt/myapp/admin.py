from django.contrib import admin
from . models import movie
admin.site.register(movie)
