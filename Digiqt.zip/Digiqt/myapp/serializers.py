from myapp.models import movie
from rest_framework import serializers

class movieserializer(serializers.ModelSerializer):
    class Meta:
        model=movie
        fields = '__all__'