#import openpyxl
import pandas as pd
xl_data = pd.read_excel(r'D:\Digiqt\myapp\movies.xlsx')
#xl_data = openpyxl.load_workbook('D:\Digiqt\myapp\movies.xlsx')
data = pd.DataFrame(xl_data,columns=['movie_name','movie_rating','movie_release','movie_duration','movie_desc'])  

print(data)