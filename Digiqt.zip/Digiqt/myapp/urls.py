from posixpath import basename
from django.db import router
from myapp.views import movieapi
from rest_framework.routers import DefaultRouter

router = DefaultRouter()
router.register('movieapi',movieapi,basename = 'movieapi')

urlpatterns = [
    
] + router.urls
