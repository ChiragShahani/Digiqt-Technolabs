from django.db import models

class movie(models.Model):
    movie_name = models.CharField(max_length=50)
    movie_rating = models.IntegerField()
    movie_release = models.DateField()
    movie_duration = models.DurationField()
    movie_desc = models.CharField(max_length=200)
    
